/*
  Scene index for keeping track of created scenes.
*/
module.exports = [];
