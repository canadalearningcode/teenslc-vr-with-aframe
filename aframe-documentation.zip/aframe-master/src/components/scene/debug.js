var register = require('../../core/component').registerComponent;

module.exports.Component = register('debug', {
  schema: {default: true}
});
