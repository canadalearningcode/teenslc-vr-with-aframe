// <a-text> using `definePrimitive` helper.
var definePrimitive = require('../primitives').definePrimitive;
definePrimitive('a-text', {text: {anchor: 'align', width: 5}});
