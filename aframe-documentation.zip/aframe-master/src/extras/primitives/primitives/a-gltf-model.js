var registerPrimitive = require('../primitives').registerPrimitive;

registerPrimitive('a-gltf-model', {
  mappings: {
    src: 'gltf-model'
  }
});
